#ifndef MAIN_H
#define MAIN_H

// Modulo de Arvore Bianria
#define MAX_STR 64

#endif