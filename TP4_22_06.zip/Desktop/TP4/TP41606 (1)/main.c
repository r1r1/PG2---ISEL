#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "TP2.h"
#include "dataManagement.h"
#include "readDataTable.h"
#include "main.h"

void printTree(TNode *r)
{

  if (r == NULL)
    return;

  printTree(r->left);
  printTree(r->right);
  printf("Ptr to list: %p, word: %s\n", r->list, r->word);
}

void print(LNode *head) {
    LNode *current_node = head;
   	while ( current_node != NULL) {
        printf("%s\n", current_node->ref->title);
        current_node = current_node->next;
    }
}

int main(int argc, char **argv)
{

  
  if(argc < 2){
    printf("Error! Usage is: ./TP4 <NameOfFile>\n");
    exit(-1);
  }

  printf("\n"
    "a - (artists) apresenta a lista de faixas áudio ordenada por Artist\n"
    "t - (titles) apresenta a lista de faixas áudio ordenada por Title\n"
    "s - (search) para procurar uma faixa\n"
    "q - (quit) termina");
  
  Manage_t *man = manCreate();

  int ret = tableReadStore(argv[1], man);

  if (ret == -1)
    return -1;

  
  manSort(man);

  char aux[64];
  
  
  while(1){
    printf("\n\nIntroduza o comando:");
    gets(aux);
    if(strcmp(aux,"q") == 0)
      break;
    manCommand(man, aux);
  }
  

  manDelete(man);

  return 0;
}
