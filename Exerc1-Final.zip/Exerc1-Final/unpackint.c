#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>

#define NumOfBits   (sizeof(int) * (8)) //Numero de Bits de um numero inteiro da arquitetura em trabalho
#define TAMANHO     100                 //Tamanho do Buffer do conteudo do ficheiro


unsigned int coutBits(int n) {  //Função para contar o numero de bits necessarios para representar de um numero inteiro 
    unsigned int count = 0;

    for(int i = 0; i < NumOfBits; i++) {
        if((1 << i) & n)
            count = i;
    }
    return ++count;
}

int signExtend(int value, int size) {
    
    int aux = -1;   //valor com tudo a 1

    for(int i = 0; i < size; i++) //Colocar até ao bit d size do valor a 0
        aux &= ~(1UL << i);
    
    return aux | value; //Colocar o valor a negativo
}

int main( int argc, char *argv[] ){

    int res = 0, i = 0, cout = 0, negativo = 0;

    if(argc != 2) {
        printf("Erro no Número de Aregumentos\n");
        printf("Exemplo: >./exerc1 [file].bin\n");
        return -1;
    }
    
    FILE *file;
    char dataRead[TAMANHO] = {0}; //Conteudo do Ficheiro
    size_t  numElem = 0; //Número de Elementos Lidos
    
    file = fopen(argv[1], "rb");

    if(file == NULL) {
        printf("Erro ao Abrir o Ficheiro\n");
        printf("Exemplo: >./exerc1 [file].bin\n");
        return -1;
    }

    numElem = fread(&dataRead, sizeof(char), TAMANHO, file);

    fclose(file);

    if(numElem == 0) {
        printf("Ficheiro Vazio ou Erro ao Ler o Ficheiro\n");
        return -1;
    }
    
    while(i < numElem) {
        if((dataRead[i] & 0x80) != 0) { 
            if((dataRead[i] & 0xF0) == 0xF0)  //Numero negativo
                negativo = 1;

            dataRead[i] = dataRead[i] & 0x7F;   //TIRAR O BIT TERMINADOR
            
            for(int j = i; cout >= 0; j--, cout--) {
                res |= (dataRead[j]);
                if(cout == 0) 
                    break;
                else res = (res << 7);
            }
            
            if(negativo == 1)
                printf("%d ", signExtend(res, coutBits(res)));
            else
                printf("%d ", res);

            res = 0; cout = 0, negativo = 0;;
        } else {
            cout++;
        }
        i++;
    }    
    printf("\n");
    return 0;
}