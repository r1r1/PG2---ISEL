#include "TP4.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

long countNodes(TNode *r) {
  int c = 1;
  if (r == NULL)
    return 0;

  else {
    c += countNodes(r->left);
    c += countNodes(r->right);
    return c;
  }
}

void ErrorMsg(void *ptr, char *str) {
  if (ptr == NULL) {
    printf("%s\n", str);
    exit(-1);
  }
}

Manage_t *manCreate(void) {

  Manage_t *man = malloc(sizeof(Manage_t));
  man->bst = malloc(sizeof(TNode));
  man->bst = NULL;

  man->refA = dinRefCreate(INITIALREFSIZE);
  man->refT = dinRefCreate(INITIALREFSIZE);

  return man;
}

void manDelete(Manage_t *man) {

  dinRefDelete(man->refA);
  dinRefDelete(man->refT);
  tDelete(man->bst);
  free(man);

  printf("\n\nFreed all memory\n");
}

void manAddTag(Manage_t *man, MP3Tag_t *tag) {
  dinRefAdd(man->refA, tag);
  dinRefAdd(man->refT, tag);

  char sc[128];
  strcpy(sc, tag->title);
  char *p = strtok(sc, " \t\n");

  while (p != NULL) {
    tAddWordRef(&man->bst, p, tag);
    p = strtok(NULL, " \t\n");
  }
}

void manSort(Manage_t *man) {
  dinRefSort(man->refA, aCompFunc);
  dinRefSort(man->refT, tCompFunc);

  long nodeCount = countNodes(man->bst);

  man->bst = treeToSortedList(man->bst, NULL);
  man->bst = sortedListToBalancedTree(&(man->bst), nodeCount);
}

void manCommand(Manage_t *man, char *cmdLine) {
  char aux[64];
  if (strcmp(cmdLine, "a") == 0 || strcmp(cmdLine, "A") == 0)
    dinRefScan(man->refA, printTag);

  if (strcmp(cmdLine, "t") == 0 || strcmp(cmdLine, "T") == 0)
    dinRefScan(man->refT, printTag);

  if (strcmp(cmdLine, "s") == 0 || strcmp(cmdLine, "S") == 0) {

    char aux[64];
    printf("Introduza o titulo que pretende procurar:");
    gets(aux);
    MP3Tag_t find;
    strcpy(find.title, aux);

    MP3Tag_t *found = dinRefSearch(man->refT, &find, sCompFunc);

    if (found == NULL) {
      puts("Não achei o titulo");
    } else
      printf("Achei o titulo: %s\n", found->title);
  }

  if (strcmp(cmdLine, "f") == 0 || strcmp(cmdLine, "F") == 0) {
    printf("Introduza as palavras que pretende procurar na lista de faixas:");
    gets(aux);
    TNode *findWord;
  }
}

int tableReadStore(char *tableName, Manage_t *man) {

  char buf[255];
  char *fieldsFound[8];
  int res = 0;
  int AuxSize = 1024;
  MP3Tag_t *tag = malloc(AuxSize * sizeof(MP3Tag_t));
  int tagCount = 0;

  FILE *File = fopen(tableName, "r");
  fgets(buf, sizeof(buf), File); // Ignora a primeira linha

  while (fgets(buf, sizeof(buf), File) != NULL) {
    res = fields(buf, fieldsFound, sizeof(fieldsFound));

    if (res != 0) {

      if (tagCount == AuxSize) {
        tag = realloc(tag, (2 * AuxSize) * sizeof(MP3Tag_t));
        AuxSize += AuxSize;
      }
      loadTag(fieldsFound, &tag[tagCount]);
      manAddTag(man, &tag[tagCount]);
      tagCount++;
    } else
      return -1;
  }
  fclose(File);
  return 0;
}

void lAddRef(LNode **hp, MP3Tag_t *tag) {

  if (*hp == NULL) {
    *hp = malloc(sizeof(LNode));
    ErrorMsg(*hp, "Erro ao alocar memoria");

    (*hp)->ref = malloc(sizeof(MP3Tag_t));
    ErrorMsg((*hp)->ref, "Erro ao alocar memoria");

    (*hp)->next = NULL;
    (*hp)->ref = tag;
  }

  else {
    lAddRef(&(*hp)->next, tag);
  }
}

void lDelete(LNode *h) {
  if (h == NULL)
    return;

  lDelete(h->next);
  free(h);
  // printf("Dei Free\n");
}

void lPrintList(LNode *node) {
  LNode *next = node;

  while (next != NULL) {
    printf("%s\n", next->ref->artist);
    next = next->next;
  }
}

void lScan(LNode *h, void (*action)(MP3Tag_t *)) {
  LNode *tmp = h;

  while (tmp != NULL) {
    action(tmp->ref);
    tmp = tmp->next;
  }
}

void printTags(MP3Tag_t *teste) { printf("Artist: %s\n", teste->artist); }

void tAddWordRef(TNode **rp, char *w, MP3Tag_t *tag) {

  if (*rp == NULL) {

    *rp = malloc(sizeof(TNode));
    ErrorMsg(*rp, "Erro ao alocar memoria");

    (*rp)->word = malloc(strlen(w));
    ErrorMsg((*rp)->word, "Erro ao alocar memoria");

    lAddRef(&(*rp)->list, tag);
    ErrorMsg((*rp)->list, "Erro ao alocar memoria");

    (*rp)->list->ref = malloc(sizeof(MP3Tag_t));
    ErrorMsg((*rp)->list->ref, "Erro ao alocar memoria");

    (*rp)->left = (*rp)->right = NULL;
    (*rp)->word = strdup(w);
    // printf("%s\n", (*rp)->word);

    return;
  }

  int ret = strcmp((*rp)->word, w);

  if (ret < 0)
    tAddWordRef(&(*rp)->right, w, tag);

  if (ret > 0)
    tAddWordRef(&(*rp)->left, w, tag);

  return;
}

void tDelete(TNode *r) {
  if (r == NULL)
    return;

  tDelete(r->left);
  tDelete(r->right);

  lDelete(r->list);
  free(r->word);
  free(r);
}

TNode *tSearch(TNode *r, char *w) {
  int res;
  if (r == NULL) {
    printf("tSearch: Morreu ya nulo\n");
    return NULL;
  }

  if (r->word != NULL) {
    res = strcmp(w, r->word);

    if (res == 0) {
      return r;
    }

    if (res < 0) {
      return tSearch(r->left, w);
    }

    else if (res > 0) {
      return tSearch(r->right, w);
    }
  }
  return r;
}

TNode *treeToSortedList(TNode *r, TNode *link) {
  TNode *p;
  if (r == NULL)
    return link;
  p = treeToSortedList(r->left, r);
  r->left = NULL;
  r->right = treeToSortedList(r->right, link);
  return p;
}

TNode *sortedListToBalancedTree(TNode **list, int n) {
  if (n == 0)
    return NULL;
  TNode *leftChild = sortedListToBalancedTree(list, n / 2);
  TNode *parent = *list;
  parent->left = leftChild;
  *list = (*list)->right;
  parent->right = sortedListToBalancedTree(list, n - (n / 2 + 1));
  return parent;
}