#include "TP3.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void) {

  Manage_t *manage = manCreate();
  char command[32];

  if (manage == NULL)
    return -1;

  int ret = tableReadStore("tag-table.csv", manage);

  manSort(manage);

  while (1) {

    printf("\nIntroduza o comando que pretende: ");
    scanf("%s", command);
    getchar();

    if (!strcmp(command, "q"))
      break;

    manCommand(manage, command);
  }

  manDelete(manage);
  return 0;
}