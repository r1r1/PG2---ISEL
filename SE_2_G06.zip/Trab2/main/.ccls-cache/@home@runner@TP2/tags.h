#include <stdio.h>
#include <stdlib.h>

#define MAX_TIT     32
#define MAX_ALB     32
#define MAX_COM     64
#define MAX_ART     32
#define MAX_TAGS    32



typedef struct{
 char title[MAX_TIT + 1];
 char artist[MAX_ART + 1];
 char album[MAX_ALB + 1];
 short year;
 char comment[MAX_COM + 1];
 char track;
 char genre;
} MP3Tag_t;

typedef struct{
 int count; // Quantidade de elementos preenchidos no campo tags.
 MP3Tag_t tags[MAX_TAGS]; // Array de tags.
} TagArr_t;

typedef struct{
 int count; // Quantidade de elementos preenchidos no campo refs.
 MP3Tag_t *refs[MAX_TAGS]; // Array de ponteiros para tag.
} TagRef_t; 