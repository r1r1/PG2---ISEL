#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tags.h"

void tagArrInit( TagArr_t *data){
  data->count = 0;
}

int tagArrAdd ( TagArr_t *data, MP3Tag_t *tag){
  
  int NoOfTags = sizeof(data->tags) / sizeof(MP3Tag_t); // Numero de elementos de Tags
  int index = data->count;                              // Indice do array de tags onde se guarda *tag caso possivel
  
  if(data->count < NoOfTags){
    data->tags[index] = *tag;
    return 0;
  }

  return -1;
  
}


int main(void) {

  TagArr_t tArr;
  tagArrInit(&tArr);
  MP3Tag_t tMP3;

  tArr.count = 31;

  int ret = tagArrAdd(&tArr, &tMP3);
  printf("Return of function was: %d\n", ret);
  

  return 0;
}
