#include "tags.h"

void tagArrInit(TagArr_t *data) { 
  data->count = 0; 
}

int tagArrAdd(TagArr_t *data, MP3Tag_t *tag) {
  int NoOfTags =
      sizeof(data->tags) / sizeof(MP3Tag_t); // Numero de elementos de Tags
  int index =
      data->count; // Indice do array de tags onde se guarda *tag caso possivel

  if (data->count < NoOfTags) {
    data->tags[index] = *tag;
    data->count++;
    return 0;
  }
  return -1;
}

int aCompFunc(const void *ptr1, const void *ptr2) {
  MP3Tag_t *tag1 = (MP3Tag_t *)ptr1;
  MP3Tag_t *tag2 = (MP3Tag_t *)ptr2;

  int res = strcmp(tag1->artist, tag2->artist);
  if (res != 0)
    return res;

  res = strcmp(tag1->album, tag2->album);
  if (res != 0)
    return res;

  return strcmp(tag1->title, tag2->title);
}

int tCompFunc(const void *ptr1, const void *ptr2) {
  MP3Tag_t *tag1 = *(MP3Tag_t **)ptr1;
  MP3Tag_t *tag2 = *(MP3Tag_t **)ptr2;

  int res = strcmp(tag1->title, tag2->title);
  if (res != 0)
    return res;

  res = strcmp(tag1->artist, tag2->artist);
  if (res != 0)
    return res;

  return strcmp(tag1->album, tag2->album);
}

void setupEnd(TagArr_t *data, TagRef_t *ref) {
  ref->count = 0;
  for (int i = 0; i < data->count; i++) {
    ref->refs[i] = &(data->tags[i]);
    ref->count++;
  }

  if (data->count != ref->count) {
    printf("Erro a passar array de referências");
    exit(0);
  }
  // Ordenar data por: 1 - Artist, 2 - Album, 3 - Title
  qsort(data->tags, data->count, sizeof(data->tags[0]), aCompFunc);

  // Ordenar data por: 1 - Title, 2 - Artist, 3 - Album
  qsort(ref->refs, ref->count, sizeof(ref->refs[0]), tCompFunc);
}

char *cutEndingSpaces(char *str) {
  char *endOfToken = str + strlen(str) - 1;
  int count = 0;

  // Verificação se a string só tem espaçamentos
  for (int j = 0; j < strlen(str); j++) {
    if (isspace(str[j]))
      count++;
  }
  // String Vazia em caso de só espaçamentos
  if (count == strlen(str))
    return "\0";

  while (isspace(*str))
    str++;

  while (isspace(*endOfToken))
    endOfToken--;

  *(endOfToken + 1) = '\0';

  return str;
}

int fields(char *line, char *ptrs[], int max_fields) {
  char *found;
  int identifiedFields = 0;

  while ((found = strsep(&line, ";")) != NULL) {

    if (identifiedFields < max_fields) {
      ptrs[identifiedFields] = cutEndingSpaces(found);
    }
    identifiedFields++;
  }
  return identifiedFields;
}

int sCompFunc(const void *ptr1, const void *ptr2) {
  MP3Tag_t *tag1 = (MP3Tag_t *)ptr1;
  MP3Tag_t *tag2 = *(MP3Tag_t **)ptr2;

  int res = strcmp(tag1->title, tag2->title);
  return res;
}

void command(TagArr_t *data, TagRef_t *ref, char *cmdLine) { // a t s q
  char titulo[MAX_TIT];
  char **res;

  if (*cmdLine == 'a' || *cmdLine == 't')
    printTable(*cmdLine, data, ref);

  else if (*cmdLine == 'q') {
    printf("Terminado por ordem do utilizador\n");
    exit(0);
  } else if (*cmdLine == 's') {
    printf("Insira o Título que Pretende Pesquisar: ");
    gets(titulo);

    res = (char **)bsearch(titulo, ref->refs, ref->count,
                           sizeof((ref->refs[0])), sCompFunc);
    if (res != NULL)
      printf("Titulo Encontrado: %s\n", *res);
    else
      printf("Título Não Encontrado\n");
  } else {
    printf("O Comando Apresentado Não Corresponde a Nenhum Comando Listado\n");
  }
}

int tableRead(char *tableName, TagArr_t *data) {
  char buf[BUFFER];
  char *fieldsFound[8];
  int res = 0;
  MP3Tag_t tag;

  FILE *File = fopen(tableName, "r");

  if(File == NULL) {
    printf("Erro: Ficheiro Não Encontrado...\n");
    return -1;
  }

  fgets(buf, sizeof(buf), File); // Ignora a primeira linha

  while (fgets(buf, sizeof(buf), File) != NULL) {
    res = fields(buf, fieldsFound, sizeof(fieldsFound));

    if (res != 0) {
      loadTag(fieldsFound, &tag);
      int ret = tagArrAdd(data, &tag);

      if (ret == -1) {
        printf("Error: Tag Array is full!\n");
        fclose(File);
        return -1;
      }
    }
  }
  fclose(File);
  return 0;
}

void loadTag(char **fieldsFound, MP3Tag_t *tag) {
  strcpy(tag->title, fieldsFound[0]);
  strcpy(tag->artist, fieldsFound[1]);
  strcpy(tag->album, fieldsFound[2]);
  tag->year = atoi(fieldsFound[3]);
  strcpy(tag->comment, fieldsFound[4]);
  tag->track = *fieldsFound[5];
  tag->genre = *fieldsFound[6];
}

void printTable(char option, TagArr_t *data, TagRef_t *ref) {
  if (option == 'a') {
    for (int i = 0; i < data->count; i++) {
      printf("%s;%s;%s;%d;%s", (data->tags[i].artist), (data->tags[i].album),
             (data->tags[i].title), data->tags[i].year, data->tags[i].comment);
      printf(";%c;%c\n", data->tags[i].track, data->tags[i].genre);
    }
  } else {
    for (int i = 0; i < ref->count; i++) {
      printf("%s;%s;%s;%d;%s;%c;%c\n", (ref->refs[i]->title),
             (ref->refs[i]->artist), (ref->refs[i]->album),
             (ref->refs[i]->year), ref->refs[i]->comment, ref->refs[i]->track,
             ref->refs[i]->genre);
    }
  }
}