#include "tags.h"

int main(int argc, char** argv) {
  TagArr_t tArr;
  TagRef_t rArr;
  char scan;

  tagArrInit(&tArr);

  int read = tableRead(argv[1], &tArr);

  if(read == -1)  //Ficheiro não encontrado
    exit(-1);
  
  setupEnd(&tArr, &rArr);

  while (1) {
    printf("\n\nIntroduza o comando que pretende realizar:\n"
           "a - Listar por Artist - Album - Title\n"
           "t - Listar por Title - Artist - Album\n"
           "s - Procurar música\n"
           "q   - Sair\n\n");

    scanf("%c", &scan);
    getchar();
    command(&tArr, &rArr, &scan);
  }

  return 0;
}