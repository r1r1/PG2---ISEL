#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "dataManagement.h"

Manage_t *manCreate(void)
{
  Manage_t *man = malloc(sizeof(Manage_t));
  man->bst = malloc(sizeof(TNode));
  man->bst = NULL;

  man->refA = dinRefCreate(INITIALREFSIZE);
  man->refT = dinRefCreate(INITIALREFSIZE);

  return man;
}

void manDelete(Manage_t *man)
{
  dinRefDelete(man->refA);
  dinRefDelete(man->refT);
  tDelete(man->bst);
  free(man);

  printf("\n\nFreed all memory\n");
}

void manAddTag(Manage_t *man, MP3Tag_t *tag)
{
  dinRefAdd(man->refA, tag);
  dinRefAdd(man->refT, tag);

  char sc[128];
  strcpy(sc, tag->title);
  char *p = strtok(sc, " \t\n");

  while (p != NULL)
  {
    tAddWordRef(&man->bst, p, tag);
    p = strtok(NULL, " \t\n");
  }
}

void manSort(Manage_t *man)
{
  dinRefSort(man->refA, aCompFunc);
  dinRefSort(man->refT, tCompFunc);

  long nodeCount = countNodes(man->bst);

  man->bst = treeToSortedList(man->bst, NULL);
  man->bst = sortedListToBalancedTree(&(man->bst), nodeCount);
}

void manCommand(Manage_t *man, char *cmdLine)
{
  char aux[64];
  if (strcmp(cmdLine, "a") == 0 || strcmp(cmdLine, "A") == 0)
    dinRefScan(man->refA, printTag);

  if (strcmp(cmdLine, "t") == 0 || strcmp(cmdLine, "T") == 0)
    dinRefScan(man->refT, printTag);

  if (strcmp(cmdLine, "s") == 0 || strcmp(cmdLine, "S") == 0)
  {
    char aux[64];
    printf("Introduza o titulo que pretende procurar: ");
    gets(aux);
    MP3Tag_t find;
    strcpy(find.title, aux);

    MP3Tag_t *found = dinRefSearch(man->refT, &find, sCompFunc);

    if (found == NULL)
      puts("Não achei o titulo");

    else
      printf("Achei o titulo: %s\n", found->title);
  }

  if (strcmp(cmdLine, "f") == 0 || strcmp(cmdLine, "F") == 0)
  {
    printf("Introduza as palavras que pretende procurar na lista de faixas: ");
    gets(aux);
    TNode *find;

    find = tSearch(man->bst, aux);
    if (find == NULL)
      printf("Não encontrei nenhuma faixa com a palavra %s\n", aux);

    else
      printf("Found: [%s]\n", find->list->ref->title);
  }
}

void printTags(MP3Tag_t *teste)
{
  printf("Title: %s\n", teste->title);
}
