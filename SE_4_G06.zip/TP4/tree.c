#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tree.h"

/**
 * @brief
 *
 * Função Auxiliar para verificar se o espaço alocado de memória da função malloc()
 * foi realizado correntamente;
 *
 * @param ptr
 * @param str
 */
void ErrorMsg(void *ptr, char *str)
{
  if (ptr == NULL)
  {
    printf("%s\n", str);
    exit(-1);
  }
}

/**
 * @brief
 *
 * Função Auxiliar que realiza a comparação de titulos
 *
 * @param ptr1
 * @param ptr2
 * @return int
 */
int titleCompare(const void *ptr1, const void *ptr2)
{
  MP3Tag_t *tag1 = (MP3Tag_t *)ptr1;
  MP3Tag_t *tag2 = (MP3Tag_t *)ptr2;

  int res = strcmp(tag1->title, tag2->title);

  if (res == 0)
  {
    int artist = strcmp(tag1->artist, tag2->artist);

    if (artist == 0)
      return strcmp(tag1->album, tag2->album);
    else
      return artist;
  }
  return res;
}

/**
 * @brief
 *
 * Cria dois pointers para a estrutura LNode;
 * Ciclo for() para realizar a ordenação da lista;
 * Na estrutra de referências coloca o conteudo de @tag;
 * No nó seguinte coloca o conteudo de @p;
 * Se o conteudo de @p for igual ao apontado por @hp, coloca o conteudo de @n no apontado por @hp;
 * Caso contrário, coloca o conteúdo de @n, no nó seguinte;
 *
 * @param hp
 * @param tag
 * @return * void
 */
void lAddRef(LNode **hp, MP3Tag_t *tag)
{
  LNode *p, *a;

  for (p = *hp; p != NULL && titleCompare(tag, p->ref) > 0; a = p, p = p->next)
    ;

  LNode *n = malloc(sizeof *n);
  n->ref = tag;
  n->next = p;

  if (p == *hp)
    *hp = n;
  else
    a->next = n;
}

/**
 * @brief
 *
 * Se o primeiro nó for NULL, cria um;
 * De seguida faz a comparação entre strings de cada nó, consoante a comparação
 * vai percorrendo os nós da esquerda ou da direita recursivamente;
 *
 * @param rp
 * @param w
 * @param tag
 */
void tAddWordRef(TNode **rp, char *w, MP3Tag_t *tag)
{
  if (*rp == NULL)
  {
    TNode *n = malloc(sizeof(TNode));
    *n = (TNode){NULL, NULL, strdup(w)};
    lAddRef(&n->list, tag);
    *rp = n;
    return;
  }

  int cmp = strcmp(w, (*rp)->word);

  if (cmp == 0)
  {
    lAddRef(&(*rp)->list, tag);
    return;
  }

  if (cmp < 0)
    tAddWordRef(&(*rp)->left, w, tag);
  else
    tAddWordRef(&(*rp)->right, w, tag);
}

/**
 * @brief
 *
 * Esta função elimina a árvore identificada pelo parâmetro r (root). Deve libertar a memória
 * dinamicamente alojada para os nós da lista, para as palavras que eles representam e para as respetivas
 * listas ligadas de referências, utilizando a função lDelete.
 *
 * @param r
 */
void tDelete(TNode *r)
{
  if (r == NULL)
    return;

  tDelete(r->left);
  tDelete(r->right);

  lDelete(r->list);
  free(r->word);
  free(r);
}

/**
 * @brief
 *
 * Esta função procura, na árvore binária de pesquisa identificada por r (root), a palavra indicada por w,
 * e retorna o endereço do respetivo nó ou NULL se não existir.
 *
 * @param r
 * @param w
 * @return TNode*
 */
TNode *tSearch(TNode *r, char *w)
{
  int res;
  if (r == NULL)
  {
    return NULL;
  }

  if (r->word != NULL)
  {
    res = strcmp(w, r->word);

    if (res == 0)
      return r;

    if (res < 0)
      return tSearch(r->left, w);

    else if (res > 0)
      return tSearch(r->right, w);
  }
  return r;
}

TNode *treeToSortedList(TNode *r, TNode *link)
{
  TNode *p;
  if (r == NULL)
    return link;
  p = treeToSortedList(r->left, r);
  r->left = NULL;
  r->right = treeToSortedList(r->right, link);
  return p;
}

TNode *sortedListToBalancedTree(TNode **list, int n)
{
  if (n == 0)
    return NULL;
  TNode *leftChild = sortedListToBalancedTree(list, n / 2);
  TNode *parent = *list;
  parent->left = leftChild;
  *list = (*list)->right;
  parent->right = sortedListToBalancedTree(list, n - (n / 2 + 1));
  return parent;
}

/**
 * @brief
 *
 * Função que conta o número de nós existentes na árvore;
 *
 * @param r
 * @return long
 */
long countNodes(TNode *r)
{
  int c = 1;
  if (r == NULL)
    return 0;
  else
  {
    c += countNodes(r->left);
    c += countNodes(r->right);
    return c;
  }
}

/**
 * @brief
 *
 * Esta função elimina a lista identificada pelo parâmetro h. Liberta a memória dinamicamente
 * alojada para os nós da lista, mas não a das tags referenciadas.
 *
 * @param h
 */
void lDelete(LNode *h)
{
  if (h == NULL)
    return;

  lDelete(h->next);
  free(h);
}

void lPrintList(LNode *node)
{
  LNode *next = node;

  while (next != NULL)
  {
    printf("%s\n", next->ref->artist);
    next = next->next;
  }
}

/**
 * @brief
 *
 * Esta função percorre a lista ligada, identificada pelo parâmetro h (head), aplicando a função passada
 * em action a cada uma das tags referenciadas. Esta função é útil, nomeadamente, para apresentar os
 * dados das tags em standard output.
 *
 * @param h
 * @param action
 */
void lScan(LNode *h, void (*action)(MP3Tag_t *))
{
  LNode *tmp = h;

  while (tmp != NULL)
  {
    printf("List: %p\n", tmp);
    action(tmp->ref);
    tmp = tmp->next;
  }
}