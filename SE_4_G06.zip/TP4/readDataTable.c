#include "readDataTable.h"

int tableReadStore(char *tableName, Manage_t *man)
{
    char buf[255];
    char *fieldsFound[8];
    int res = 0;
    int AuxSize = 1024;
    MP3Tag_t *tag = malloc(AuxSize * sizeof(MP3Tag_t));
    int tagCount = 0;

    FILE *File = fopen(tableName, "r");
    fgets(buf, sizeof(buf), File); // Ignora a primeira linha

    while (fgets(buf, sizeof(buf), File) != NULL)
    {
        res = fields(buf, fieldsFound, sizeof(fieldsFound));

        if (res != 0)
        {

            if (tagCount == AuxSize)
            {
                tag = realloc(tag, (2 * AuxSize) * sizeof(MP3Tag_t));
                AuxSize += AuxSize;
            }
            loadTag(fieldsFound, &tag[tagCount]);
            manAddTag(man, &tag[tagCount]);
            tagCount++;
        }
        else
            return -1;
    }
    fclose(File);
    return 0;
}