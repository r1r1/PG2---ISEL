#ifndef DATAMANAGEMENT_H
#define DATAMANAGEMENT_H

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "tree.h"

Manage_t *manCreate(void);

void manDelete(Manage_t *man);

void manAddTag(Manage_t *man, MP3Tag_t *tag);

void manSort(Manage_t *man);

void manCommand(Manage_t *man, char *cmdLine);

void lPrintList(LNode *node);

void printTags(MP3Tag_t *teste);

#endif