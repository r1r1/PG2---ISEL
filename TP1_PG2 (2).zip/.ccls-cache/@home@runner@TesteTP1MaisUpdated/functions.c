#include <ctype.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *cutEndingSpaces(char *str) {

  char *endOfToken = str + strlen(str) - 1;
  int i = 0;
  int count = 0;

  // Verificação se a string só tem espaçamentos
  for (int j = 0; j < strlen(str); j++) {
    if (isspace(str[j]))
      count++;
  }
  // String Vazia em caso de só espaçamentos
  if (count == strlen(str))
    return "\0";

  while (isspace(*str))
    str++;

  while (isspace(*endOfToken))
    endOfToken--;

  *(endOfToken + 1) = '\0';

  return str;
}

int fields(char *line, char *ptrs[], int max_fields) {

  char *found;
  int identifiedFields = 0;

  while ((found = strsep(&line, ";")) != NULL) {

    if (identifiedFields < max_fields) {
      ptrs[identifiedFields] = cutEndingSpaces(found);
    }

    identifiedFields++;
  }

  return identifiedFields;
}