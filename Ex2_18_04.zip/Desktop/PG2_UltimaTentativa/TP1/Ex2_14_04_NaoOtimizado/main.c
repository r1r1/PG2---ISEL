#include "functions.h"
#include <ctype.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SIZEOFSTR 200
#define SIZEPTRSTORE  8

int main(int argc, char **argv) {

  char str[SIZEOFSTR];
  char *ptrs[SIZEPTRSTORE] = {NULL};
  int identifiedFields = 0;
  int argNumbers[argc - 1];
  int arrayElems = argc - 1;
  int Field = 0;


  printf("Usage ./Exercicio2 < filename fields(optional)\n\n");
 
  // Guardar campos a dar print
  for (int i = 1, j = 0; i <= argc - 1; i++, j++) {
    argNumbers[j] = atoi(argv[i]);
  }

  
  while (fgets(str, SIZEOFSTR, stdin) != NULL) {
    identifiedFields = fields(str, ptrs, 8);

    if(arrayElems == 0){
      for(int i = 0 ; i < identifiedFields; i++){
        if (i == (identifiedFields - 1)) {
          printf("%s", ptrs[i]);
        } else {
          printf("%s;", ptrs[i]);
        }
      }
    }

    else if (arrayElems > identifiedFields) {
      for (int i = 0; i < identifiedFields; i++) {
        if (i == (identifiedFields - 1)) {
          printf("%s", ptrs[i]);
        } else {
          printf("%s;", ptrs[i]);
        }
      }
    }

    else {
      for (int i = 0; i < arrayElems; i++) {
        Field = argNumbers[i];

        if (ptrs[Field - 1] == NULL) {
          if (i == (arrayElems - 1)) {
            printf(" ");
          }
          else {
            printf(";");
          }
        } 
        else {
          if (i == (arrayElems - 1)) {
            printf("%s", ptrs[Field - 1]);
          } 
          else {
            printf("%s;", ptrs[Field - 1]);
          }
        }
      }
    }
    printf("\n");
  }

  return 0;
}