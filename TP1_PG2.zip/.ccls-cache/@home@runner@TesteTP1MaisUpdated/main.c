// Online C compiler to run C program online
#include "functions.h"
#include <ctype.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv) {

  char str[200];
  char *ptrs[8] = {NULL};
  int identifiedFields = 0;

  FILE *file = fopen("file.txt", "r");

  while (fgets(str, sizeof(str), file) != NULL){
      identifiedFields = fields(str, ptrs, 8);
      for (int i = 0; i < identifiedFields; i++) {
        printf("%s;", ptrs[i]);
      }
    printf("\n");
    }

  return 0;
}