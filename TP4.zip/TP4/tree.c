#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tree.h"

void ErrorMsg(void *ptr, char *str)
{
  if (ptr == NULL)
  {
    printf("%s\n", str);
    exit(-1);
  }
}

int titleCompare(const void *ptr1, const void *ptr2)
{
  MP3Tag_t *tag1 = (MP3Tag_t *)ptr1;
  MP3Tag_t *tag2 = (MP3Tag_t *)ptr2;

  int res = strcmp(tag1->title, tag2->title);

  if (res == 0)
  {
    int artist = strcmp(tag1->artist, tag2->artist);

    if (artist == 0)
      return strcmp(tag1->album, tag2->album);
    else
      return artist;
  }
  return res;
}

void lAddRef(LNode **hp, MP3Tag_t *tag)
{
  LNode *p, *a;

  for (p = *hp; p != NULL && titleCompare(tag, p->ref) > 0; a = p, p = p->next)
    ;

  LNode *n = malloc(sizeof *n);
  n->ref = tag;
  n->next = p;

  if (p == *hp)
    *hp = n;
  else
    a->next = n;
}

void tAddWordRef(TNode **rp, char *w, MP3Tag_t *tag)
{
  if (*rp == NULL)
  {
    TNode *n = malloc(sizeof(TNode));
    *n = (TNode){NULL, NULL, strdup(w)};
    lAddRef(&n->list, tag);
    *rp = n;
    return;
  }

  int cmp = strcmp(w, (*rp)->word);

  if (cmp == 0)
  {
    lAddRef(&(*rp)->list, tag);
    return;
  }

  if (cmp < 0)
    tAddWordRef(&(*rp)->left, w, tag);
  else
    tAddWordRef(&(*rp)->right, w, tag);
}

void tDelete(TNode *r)
{
  if (r == NULL)
    return;

  tDelete(r->left);
  tDelete(r->right);

  lDelete(r->list);
  free(r->word);
  free(r);
}

TNode *tSearch(TNode *r, char *w)
{
  int res;
  if (r == NULL)
  {
    return NULL;
  }

  if (r->word != NULL)
  {
    res = strcmp(w, r->word);

    if (res == 0)
      return r;

    if (res < 0)
      return tSearch(r->left, w);

    else if (res > 0)
      return tSearch(r->right, w);
  }
  return r;
}

TNode *treeToSortedList(TNode *r, TNode *link)
{
  TNode *p;
  if (r == NULL)
    return link;
  p = treeToSortedList(r->left, r);
  r->left = NULL;
  r->right = treeToSortedList(r->right, link);
  return p;
}

TNode *sortedListToBalancedTree(TNode **list, int n)
{
  if (n == 0)
    return NULL;
  TNode *leftChild = sortedListToBalancedTree(list, n / 2);
  TNode *parent = *list;
  parent->left = leftChild;
  *list = (*list)->right;
  parent->right = sortedListToBalancedTree(list, n - (n / 2 + 1));
  return parent;
}

long countNodes(TNode *r)
{
  int c = 1;
  if (r == NULL)
    return 0;
  else
  {
    c += countNodes(r->left);
    c += countNodes(r->right);
    return c;
  }
}

void lDelete(LNode *h)
{
  if (h == NULL)
    return;

  lDelete(h->next);
  free(h);
}

void lPrintList(LNode *node)
{
  LNode *next = node;

  while (next != NULL)
  {
    printf("%s\n", next->ref->artist);
    next = next->next;
  }
}

void lScan(LNode *h, void (*action)(MP3Tag_t *))
{
  LNode *tmp = h;

  while (tmp != NULL)
  {
    printf("List: %p\n", tmp);
    action(tmp->ref);
    tmp = tmp->next;
  }
}