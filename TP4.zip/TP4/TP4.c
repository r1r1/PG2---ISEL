#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "TP4.h"

Manage_t *manCreate(void)
{

  Manage_t *manage = malloc(sizeof(Manage_t));

  manage->bst = malloc(sizeof(TNode));
  manage->bst->left = NULL;
  manage->bst->right = NULL;
  manage->bst->list = NULL;
  manage->bst->word = NULL;

  manage->refA = dinRefCreate(INITIALSIZE);
  manage->refT = dinRefCreate(INITIALSIZE);

  return manage;
}

void manDelete(Manage_t *man)
{

  dinRefDelete(man->refA);
  dinRefDelete(man->refT);
  free(man->bst);
  free(man);

  printf("\n\nFreed all memory\n");
}

void manAddTag(Manage_t *man, MP3Tag_t *tag)
{
  dinRefAdd(man->refA, tag);
  dinRefAdd(man->refT, tag);
}

void manSort(Manage_t *man)
{
  dinRefSort(man->refA, aCompFunc);
  dinRefSort(man->refT, tCompFunc);
}

void manCommand(Manage_t *man, char *cmdLine)
{

  if (strcmp(cmdLine, "a") == 0)
    dinRefScan(man->refA, printTag);

  if (strcmp(cmdLine, "t") == 0)
    dinRefScan(man->refA, printTag);

  if (strcmp(cmdLine, "s") == 0)
  {
    char aux[64];
    printf("Introduza o titulo que pretende procurar:");
    gets(aux);
    MP3Tag_t find;
    strcpy(find.title, aux);

    MP3Tag_t *found = dinRefSearch(man->refT, &find, sCompFunc);

    if (found == NULL)
    {
      puts("Não achei o titulo");
    }
    else
      printf("Achei o titulo: %s\n", found->title);
  }
}

int tableReadStore(char *tableName, Manage_t *man)
{

  char buf[255];
  char *fieldsFound[8];
  int res = 0;
  int AuxSize = 1024;
  MP3Tag_t *tag = malloc(AuxSize * sizeof(MP3Tag_t));
  int tagCount = 0;

  FILE *File = fopen(tableName, "r");
  fgets(buf, sizeof(buf), File); // Ignora a primeira linha

  while (fgets(buf, sizeof(buf), File) != NULL)
  {
    res = fields(buf, fieldsFound, sizeof(fieldsFound));

    if (res != 0)
    {

      if (tagCount == AuxSize)
      {
        tag = realloc(tag, (2 * AuxSize) * sizeof(MP3Tag_t));
        AuxSize += AuxSize;
      }
      loadTag(fieldsFound, &tag[tagCount]);
      manAddTag(man, &tag[tagCount]);
      tagCount++;
    }
  }
  fclose(File);
  return 0;
}

void lAddRef(LNode **hp, MP3Tag_t *tag)
{

  if (*hp == NULL)
  {
    *hp = malloc(sizeof(LNode));

    if (*hp == NULL)
    {
      printf("Erro na alocação de memória\n");
      return;
    }

    (*hp)->ref = malloc(sizeof(MP3Tag_t));

    if ((*hp)->ref == NULL)
    {
      printf("Erro na alocação de memória\n");
      return;
    }

    (*hp)->next = NULL;
    (*hp)->ref = tag;
  }

  else
  {
    lAddRef(&(*hp)->next, tag);
  }
}

void lDelete(LNode *h)
{
  if (h == NULL)
    return;

  lDelete(h->next);
  // free(h->ref);
  free(h);
  printf("Dei Free\n");
}

void lPrintList(LNode *node)
{
  LNode *next = node;

  while (next != NULL)
  {
    printf("%s\n", next->ref->artist);
    next = next->next;
  }
}

void lScan(LNode *h, void (*action)(MP3Tag_t *))
{
  LNode *tmp = h;

  while (tmp != NULL)
  {
    action(tmp->ref);
    tmp = tmp->next;
  }
}

void printTags(MP3Tag_t *teste)
{
  printf("Artist: %s\n", teste->artist);
}