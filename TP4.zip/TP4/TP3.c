#include "TP4.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

DinRef_t *dinRefCreate(int initSpace) {

  DinRef_t *references = malloc(sizeof(DinRef_t));

  if (references == NULL) {
    printf("Erro na criação de DinRef_t! \n");
    return NULL;
  }

  references->refs = malloc(sizeof(MP3Tag_t *) * initSpace);
  references->count = 0;
  references->space = initSpace;

  return references;
}

void dinRefDelete(DinRef_t *ref) {
  free(ref->refs);
  free(ref);
}

void dinRefAdd(DinRef_t *ref, MP3Tag_t *tag) {

  int count = ref->count;

  if (ref->count == ref->space) {
    ref->refs =
        realloc(ref->refs, (ref->space + REDIMENSION) * sizeof(MP3Tag_t *));
    ref->space += REDIMENSION;
  }

  ref->refs[count] = tag;

  (ref->count)++;
}



void dinRefSort(DinRef_t *ref, int (*compar)(const void *, const void *)) {
  qsort(ref->refs, ref->count, sizeof(ref->refs[0]), compar);
}

void dinRefScan(DinRef_t *ref, void (*action)(MP3Tag_t *)) {

  for (int i = 0; i < ref->count; i++) {
    action(ref->refs[i]);
  }
}



void printTag(MP3Tag_t *tag) {
  printf("%s;%s;%s;%d;%s", (tag->artist), (tag->album), (tag->title), tag->year,
         tag->comment);
  printf(";%c;%c\n", tag->track, tag->genre);
}

int sCompFunc(const void *ptr1, const void *ptr2) {
  MP3Tag_t *tag1 = (MP3Tag_t *)ptr1;
  MP3Tag_t *tag2 = *(MP3Tag_t **)ptr2;

  int res = strcmp(tag1->title, tag2->title);
  return res;
}

MP3Tag_t *dinRefSearch(DinRef_t *ref, void *key,
                       int (*compar)(const void *, const void *)) {

  MP3Tag_t *toFind = (MP3Tag_t *)key;
  MP3Tag_t **found =
      bsearch(toFind, ref->refs, ref->count, sizeof(ref->refs[0]), compar);

  return *found;
}



