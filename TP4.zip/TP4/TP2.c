#include "TP4.h"
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Esta função foi adaptada do TP2
// Alteração: MP3Tag_t *tag 1 = (MP3Tag_t*)ptr1; passou para MP3Tag_t *tag1 =
// *(MP3Tag_t **)ptr1;

int aCompFunc(const void *ptr1, const void *ptr2) {

  MP3Tag_t *tag1 = *(MP3Tag_t **)ptr1;
  MP3Tag_t *tag2 = *(MP3Tag_t **)ptr2;

  int res = strcmp(tag1->artist, tag2->artist);
  if (res != 0)
    return res;

  res = strcmp(tag1->album, tag2->album);
  if (res != 0)
    return res;

  return strcmp(tag1->title, tag2->title);
}

int tCompFunc(const void *ptr1, const void *ptr2) {
  MP3Tag_t *tag1 = *(MP3Tag_t **)ptr1;
  MP3Tag_t *tag2 = *(MP3Tag_t **)ptr2;

  int res = strcmp(tag1->title, tag2->title);
  if (res != 0)
    return res;

  res = strcmp(tag1->artist, tag2->artist);
  if (res != 0)
    return res;

  return strcmp(tag1->album, tag2->album);
}

char *cutEndingSpaces(char *str) {

  char *endOfToken = str + strlen(str) - 1;
  int count = 0;

  // Verificação se a string só tem espaçamentos
  for (int j = 0; j < strlen(str); j++) {
    if (isspace(str[j]))
      count++;
  }
  // String Vazia em caso de só espaçamentos
  if (count == strlen(str))
    return "\0";

  while (isspace(*str))
    str++;

  while (isspace(*endOfToken))
    endOfToken--;

  *(endOfToken + 1) = '\0';

  return str;
}

int fields(char *line, char *ptrs[], int max_fields) {

  char *found;
  int identifiedFields = 0;

  while ((found = strsep(&line, ";")) != NULL) {

    if (identifiedFields < max_fields) {
      ptrs[identifiedFields] = cutEndingSpaces(found);
    }
    identifiedFields++;
  }
  return identifiedFields;
}

void loadTag(char **fieldsFound, MP3Tag_t *tag) {

  strcpy(tag->title, fieldsFound[0]);
  strcpy(tag->artist, fieldsFound[1]);
  strcpy(tag->album, fieldsFound[2]);
  tag->year = atoi(fieldsFound[3]);
  strcpy(tag->comment, fieldsFound[4]);
  tag->track = *fieldsFound[5];
  tag->genre = *fieldsFound[6];
}
