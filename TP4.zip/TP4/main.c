#include "TP4.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Modulo de Arvore Bianria

void tAddWordRef(TNode **rp, char *w, MP3Tag_t *tag)
{
  if (*rp == NULL)
  {
    *rp = malloc(sizeof(TNode));
    if (*rp == NULL)
      printf("Erro ao alocar Mamória!\n");

    (*rp)->list->ref = malloc(sizeof()); // sizeof

    (*rp)->word = w;

    (*rp)->left = (*rp)->right = NULL;
    // falta terminar
  }
}

void tDelete(TNode *r)
{
  r = NULL;
}

TNode *tSearch(TNode *r, char *w)
{
  int res;

  if (r == NULL)
    return NULL;
  else if (r != NULL)
  {
    res = strcmp(w, r->word);
    if (res < 0)
      search(r->left, w);
    else if (res > 0)
      search(r->right, w);
    else
      return (TNode *); // falta a referência
  }
}

int main(void)
{

  LNode *teste = NULL;

  MP3Tag_t tags[10];

  for (int i = 0; i < 10; i++)
  {
    sprintf(tags[i].artist, "Tag %d", i + 1);
    lAddRef(&teste, &(tags[i]));
  }

  lScan(teste, printTags);

  // lPrintList(teste);
  lDelete(teste);

  return 0;
}