#ifndef READDATATABLE_H
#define READDATATABLE_H

#include "dataManagement.h"

int tableReadStore(char *, Manage_t *);

#endif