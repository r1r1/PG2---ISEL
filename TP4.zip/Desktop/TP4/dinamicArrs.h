#ifndef DINAMICARRS_H
#define DINAMICARRS_H

#include "TP2.h"

#define INITIALSIZE 32
#define REDIMENSION 64
#define INITIALREFSIZE 1024

typedef struct
{
    int space;
    int count;
    MP3Tag_t **refs;
} DinRef_t;

DinRef_t *dinRefCreate(int);

void dinRefDelete(DinRef_t *);

void dinRefAdd(DinRef_t *, MP3Tag_t *);

void dinRefSort(DinRef_t *, int (*)(const void *, const void *));

void dinRefScan(DinRef_t *, void (*)(MP3Tag_t *));

MP3Tag_t *dinRefSearch(DinRef_t *, void *, int (*)(const void *, const void *));

int sCompFunc(const void *, const void *);

void printTag(MP3Tag_t *);

#endif
