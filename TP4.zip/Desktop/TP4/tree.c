#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "tree.h"

void ErrorMsg(void *ptr, char *str)
{
  if (ptr == NULL)
  {
    printf("%s\n", str);
    exit(-1);
  }
}

void tAddWordRef(TNode **rp, char *w, MP3Tag_t *tag)
{

    if (*rp == NULL)
    {

        *rp = malloc(sizeof(TNode));
        ErrorMsg(*rp, "Erro ao alocar memoria");

        (*rp)->word = malloc(strlen(w));
        ErrorMsg((*rp)->word, "Erro ao alocar memoria");

        lAddRef(&(*rp)->list, tag);
        ErrorMsg((*rp)->list, "Erro ao alocar memoria");

        (*rp)->list->ref = malloc(sizeof(MP3Tag_t));
        ErrorMsg((*rp)->list->ref, "Erro ao alocar memoria");

        (*rp)->left = (*rp)->right = NULL;
        (*rp)->word = strdup(w);
        // printf("%s\n", (*rp)->word);

        return;
    }

    int ret = strcmp((*rp)->word, w);

    if (ret < 0)
        tAddWordRef(&(*rp)->right, w, tag);

    if (ret > 0)
        tAddWordRef(&(*rp)->left, w, tag);

    return;
}

void tDelete(TNode *r)
{
    if (r == NULL)
        return;

    tDelete(r->left);
    tDelete(r->right);

    lDelete(r->list);
    free(r->word);
    free(r);
}

TNode *tSearch(TNode *r, char *w)
{
    int res;
    if (r == NULL)
    {
        printf("tSearch: Morreu ya nulo\n");
        return NULL;
    }

    if (r->word != NULL)
    {
        res = strcmp(w, r->word);

        if (res == 0)
        {
            return r;
        }

        if (res < 0)
        {
            return tSearch(r->left, w);
        }

        else if (res > 0)
        {
            return tSearch(r->right, w);
        }
    }
    return r;
}

TNode *treeToSortedList(TNode *r, TNode *link)
{
    TNode *p;
    if (r == NULL)
        return link;
    p = treeToSortedList(r->left, r);
    r->left = NULL;
    r->right = treeToSortedList(r->right, link);
    return p;
}

TNode *sortedListToBalancedTree(TNode **list, int n)
{
    if (n == 0)
        return NULL;
    TNode *leftChild = sortedListToBalancedTree(list, n / 2);
    TNode *parent = *list;
    parent->left = leftChild;
    *list = (*list)->right;
    parent->right = sortedListToBalancedTree(list, n - (n / 2 + 1));
    return parent;
}

long countNodes(TNode *r)
{
    int c = 1;
    if (r == NULL)
        return 0;
    else
    {
        c += countNodes(r->left);
        c += countNodes(r->right);
        return c;
    }
}

void lAddRef(LNode **hp, MP3Tag_t *tag)
{
    if (*hp == NULL)
    {
        *hp = malloc(sizeof(LNode));
        ErrorMsg(*hp, "Erro ao alocar memoria");

        (*hp)->ref = malloc(sizeof(MP3Tag_t));
        ErrorMsg((*hp)->ref, "Erro ao alocar memoria");

        (*hp)->next = NULL;
        (*hp)->ref = tag;
    }

    else
    {
        lAddRef(&(*hp)->next, tag);
    }
}

void lDelete(LNode *h)
{
    if (h == NULL)
        return;

    lDelete(h->next);
    free(h);
    // printf("Dei Free\n");
}

void lPrintList(LNode *node)
{
    LNode *next = node;

    while (next != NULL)
    {
        printf("%s\n", next->ref->artist);
        next = next->next;
    }
}

void lScan(LNode *h, void (*action)(MP3Tag_t *))
{
    LNode *tmp = h;

    while (tmp != NULL)
    {
        action(tmp->ref);
        tmp = tmp->next;
    }
}