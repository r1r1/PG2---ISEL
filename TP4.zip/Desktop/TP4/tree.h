#ifndef TREE_H
#define TREE_H

#include "dinamicArrs.h"

typedef struct lNode // Nó de lista ligada.
{
    struct lNode *next; // Ligação na lista.
    MP3Tag_t *ref;      // Ponteiro para a tag referenciada.
} LNode;

typedef struct tNode // Nó de árvore binária de pesquisa.
{
    struct tNode *left, *right; // Ligação na árvore.
    char *word;                 // Palavra associada ao nó – string alojada dinamicamente.
    LNode *list;                // Lista ligada com as referências da palavra.
} TNode;

typedef struct
{
    DinRef_t *refA;
    DinRef_t *refT;
    TNode *bst;
} Manage_t;

void ErrorMsg(void *ptr, char *str);

void tAddWordRef(TNode **rp, char *w, MP3Tag_t *tag);

void tDelete(TNode *r);

TNode *tSearch(TNode *r, char *w);

TNode *treeToSortedList(TNode *r, TNode *link);

TNode *sortedListToBalancedTree(TNode **list, int n);

long countNodes(TNode *r);

void lAddRef(LNode **hp, MP3Tag_t *tag);

void lDelete(LNode *h);

void lScan(LNode *h, void (*action)(MP3Tag_t *));

#endif