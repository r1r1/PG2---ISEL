#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "TP2.h"
#include "dataManagement.h"
#include "readDataTable.h"
#include "main.h"

void printTree(TNode *r)
{

  if (r == NULL)
    return;

  printTree(r->left);
  printTree(r->right);
  printf("Word: %s\n", r->word);
}

int main(int argc, char **argv)
{

  Manage_t *man = manCreate();

  int ret = tableReadStore("tag-table.csv", man);

  if (ret == -1)
    return -1;

  manSort(man);
  // printTree(man->bst);

  char aux[64];
  printf("Introduza o comando:");
  gets(aux);
  manCommand(man, aux);

  manDelete(man);

  return 0;
}