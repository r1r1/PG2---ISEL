#include "functionsUnpackint.h"

int main(int argc, char *argv[]) {

    int res = 0, i = 0, cout = 0, negativo = 0;

    if( argc != 2 ){
        fprintf(stderr, "Error on Arguments;\n"
                        "Usage: %s [filename].bin\n", argv[0]);
        return -1;
    }
    
    FILE *file;
    char dataRead[TAMANHO] = {0}; //Conteudo do Ficheiro
    size_t  numElem = 0; //Número de Elementos Lidos
    
    file = fopen(argv[1], "rb");

    if(file == NULL) {
        fprintf(stderr, "Fail openning file \"%s\"\n"
                        "Example: >%s [file].bin\n", argv[1], argv[0]);
        return -2;
    }

    numElem = fread(&dataRead, sizeof(char), TAMANHO, file);

    fclose(file);

    if(numElem == 0) {
        fprintf(stderr, "Empty File or Error to Read File\n");
        return -3;
    }
    
    while(i < numElem) {
        if((dataRead[i] & 0x80) != 0) { 
            if((dataRead[i] & 0xF0) == 0xF0)  //Numero negativo
                negativo = 1;
            else 
                negativo = 0;

            dataRead[i] = dataRead[i] & 0x7F;   //Retira o bit Terminador 
            
            for(int j = i; cout >= 0; j--, cout--) {
                res |= (dataRead[j]);
                if(cout == 0) 
                    break;
                else res = (res << 7);
            }
            
            if(negativo == 1)
                printf("%d ", signExtend(res, countBits(res)));
            else
                printf("%d ", res);

            res = 0; cout = 0, negativo = 0;;
        } else {
            cout++;
        }
        i++;
    }    

    printf("\n");

    return 0;
}