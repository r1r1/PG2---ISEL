#ifndef functionsUnpackint_H_
#define functionsUnpackint_H_

#include <stdio.h>
#include <stdlib.h>

#define NumOfBits   (sizeof(int) * (8)) //Numero de Bits de um numero inteiro da arquitetura em trabalho
#define TAMANHO     100                 //Tamanho do Buffer do conteudo do ficheiro

unsigned int countBits(int n);

int signExtend(int value, int size);

#endif