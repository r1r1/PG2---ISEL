#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "tags.h"



void tagArrInit(TagArr_t *data) { data->count = 0; }

int tagArrAdd(TagArr_t *data, MP3Tag_t *tag) {

  int NoOfTags =
      sizeof(data->tags) / sizeof(MP3Tag_t); // Numero de elementos de Tags
  int index =
      data->count; // Indice do array de tags onde se guarda *tag caso possivel

  if (data->count < NoOfTags) {
    data->tags[index] = *tag;
    data->count++;
    return 0;
  }
  return -1;
}

int aCompFunc(const void *ptr1, const void *ptr2) {

  MP3Tag_t *tag1 = (MP3Tag_t *)ptr1;
  MP3Tag_t *tag2 = (MP3Tag_t *)ptr2;

  int res = strcmp(tag1->artist, tag2->artist);
  if (res != 0)
    return res;

  res = strcmp(tag1->album, tag2->album);
  if (res != 0)
    return res;

  return strcmp(tag1->title, tag2->title);
}

int tCompFunc(const void *ptr1, const void *ptr2) {
  MP3Tag_t *tag1 = *(MP3Tag_t **)ptr1;
  MP3Tag_t *tag2 = *(MP3Tag_t **)ptr2;

  int res = strcmp(tag1->title, tag2->title);
  if (res != 0)
    return res;

  res = strcmp(tag1->artist, tag2->artist);
  if (res != 0)
    return res;

  return strcmp(tag1->album, tag2->album);
}

void setupEnd(TagArr_t *data, TagRef_t *ref) {

  ref->count = 0;
  for (int i = 0; i < data->count; i++) {
    ref->refs[i] = &(data->tags[i]);
    ref->count++;
  }

  if (data->count != ref->count) {
    printf("Erro a passar array de referências");
    exit(0);
  }

  // Ordenar data por: 1 - Artist, 2 - Album, 3 - Title
  qsort(data->tags, data->count, sizeof(data->tags[0]), aCompFunc);

  // Ordenar data por: 1 - Title, 2 - Artist, 3 - Album
  qsort(ref->refs, ref->count, sizeof(ref->refs[0]), tCompFunc);
}