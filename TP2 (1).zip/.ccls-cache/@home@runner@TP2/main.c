#include "tags.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void command ( TagArr_t *data, TagRef_t *ref, char *cmdLine){
  
}

int main(void) {

  TagArr_t tArr;
  MP3Tag_t tag1, tag2;
  TagRef_t rArr;

  tagArrInit(&tArr);

  strcpy(tag1.album, "Peido");
  strcpy(tag1.artist, "RubenEx");
  strcpy(tag1.title, "Hino aos meus subscritores");
  strcpy(tag2.album, "Cueca");
  strcpy(tag2.artist, "Tiagovski");
  strcpy(tag2.title, "Hino aos meus subscritores");

  int res = tagArrAdd(&tArr, &tag1);

  if (res == -1)
    exit(0);

  res = tagArrAdd(&tArr, &tag2);

  if (res == -1)
    exit(0);

  setupEnd(&tArr, &rArr);
  printf("\nAfter sorting...\n\n");

  for (int i = 0; i < rArr.count; i++) {
    printf("Tag[%d] Artist: %s, Album: %s, Title: %s\n", i,
           (rArr.refs[i]->title), (rArr.refs[i]->artist),
           (rArr.refs[i]->album));
  }

  return 0;
}
