#include "TP2.h"
#include <stdio.h>
#include <stdlib.h>

#define REDIMENSION 64
#define INITIALSIZE 32

typedef struct {
  int space;
  int count;
  MP3Tag_t **refs;
} DinRef_t;

typedef struct {
  DinRef_t *refA;
  DinRef_t *refT;
} Manage_t;

DinRef_t *dinRefCreate(int);
void dinRefDelete(DinRef_t *);
void dinRefAdd(DinRef_t *, MP3Tag_t *);
Manage_t *manCreate(void);
void manDelete(Manage_t *);
void manAddTag(Manage_t *, MP3Tag_t *);
void dinRefSort(DinRef_t *, int (*)(const void *, const void *));
void dinRefScan(DinRef_t *, void (*)(MP3Tag_t *));
void manSort(Manage_t *);
int sCompFunc(const void *, const void *);
void printTag(MP3Tag_t *);
void manCommand(Manage_t *, char *);
int tableReadStore(char *, Manage_t *);
MP3Tag_t *dinRefSearch(DinRef_t *, void *, int (*)(const void *, const void *));