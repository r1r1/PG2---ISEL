#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>

int signExtend(int value, int size) {
    

    return value | 0xFFFFF000;
}

int main( int argc, char *argv[] ){

    if(argc != 2) {
        printf("Erro no Número de Aregumentos\n");
        printf("Exemplo: >./exerc1 [file].bin\n");
        return -1;
    }
    
    FILE *file;
    char dataRead[100] = {0}; //Conteudo do Ficheiro
    size_t  numElem = 0; //Número de Elementos Lidos
    
    file = fopen(argv[1], "rb");

    if(file == NULL) {
        printf("Erro ao Abrir o Ficheiro\n");
        printf("Exemplo: >./exerc1 [file].bin\n");
        return -1;
    }

    numElem = fread(&dataRead, sizeof(char), 100, file);

    fclose(file);

    if(numElem == 0) {
        printf("Ficheiro Vazio ou Erro ao Ler o Ficheiro\n");
        return -1;
    }

    int res = 0, i = 0, cout = 0, negativo = 0;
    
    while(i < numElem) {
        if((dataRead[i] & 0x80) != 0) { 
            if((dataRead[i] & 0xF0) == 0xF0)  //Numero negativo
                negativo = 1;

            dataRead[i] = dataRead[i] & 0x7F;   //TIRAR O BIT TERMINADOR
            
            for(int j = i; cout >= 0; j--, cout--) {
                res |= (dataRead[j]);
                if(cout == 0) 
                    break;
                else res = (res << 7);
            }
            
            if(negativo == 1)
                printf("%d ", signExtend(res, sizeof(res)));
            else
                printf("%d ", res);

            res = 0; cout = 0, negativo = 0;;
        } else {
            cout++;
        }
        i++;
    }    
    printf("\n");
    return 0;
}