#include <stdio.h>
#include <limits.h>
#include <string.h>

#define DATA_SIZE (CHAR_BIT - 1)
#define FINAL_MASK (1 << DATA_SIZE)
#define DATA_MASK (~(~0 << DATA_SIZE))
#define SIGN_SIZE 1

int signExtend(int value, int size) {

    __int8_t lowByte = value % 10;
    __int8_t highByte = value / 10;

    //converter em hexadecimal

    if((highByte >> 3) & 0x01) {   //encontrar o terminador
        printf("%d\n", lowByte);
        return lowByte;
    } else {
        printf("negativo");
        return 2;
    }

    
}

int signTeste(int value, int size) {
    int alto = value & 0x000000FF;
    int baixo = value & 0x0000FF00;
    int resultado = (alto << 8) | (baixo >> 8); 
   
    printf("resu = %d\n", resultado);

    int aux= ~(resultado & 0x00000FFF);
    resultado = aux & resultado;
    printf("resu = %d\n", resultado);
}

int main( int argc, char *argv[] ){

    if(argc != 2) {
        printf("Erro no Número de Aregumentos\n");
        printf("Exemplo: >./exerc1 [file].bin\n");
        return -1;
    }

    FILE *file;
    char dataRead[100] = {0}; //Conteudo do Ficheiro
    size_t  numElem = 0; //Número de Elementos Lidos
    
    file = fopen(argv[1], "rb");

    if(file == NULL) {
        printf("Erro ao Abrir o Ficheiro\n");
        printf("Exemplo: >./exerc1 [file].bin\n");
        return -1;
    }

    numElem = fread(&dataRead, sizeof(char), 100, file);

    fclose(file);

    if(numElem == 0) {
        printf("Ficheiro Vazio ou Erro ao Ler o Ficheiro\n");
        return -1;
    }

    for(int i = 0; i < numElem; i++) 
        printf("Conteudo: %c\n", dataRead[i]);

    signExtend(30, 1);

    int resultado = dataRead[0] - dataRead[1];
    resultado = (resultado << 1) | 0x0001;

    printf("resultado = %d\n", resultado);

    signTeste(12528, 1);

    return 0;
}