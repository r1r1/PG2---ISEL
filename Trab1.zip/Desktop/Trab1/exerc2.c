#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

char *cutEndingSpaces(char *str) {
    
    if(NULL == str)
        return str;

    int n = 0;

    for(int i = 0; i < strlen(str); i++) {   //converter todos \t e \n em espaços
        if((str[i] == '\n') || (str[i] == '\t'))
            str[i] = ' ';
    }

    for(int i = 0; i < strlen(str); i++) {  //Eliminar os Espaços no meio da string
        if((str[i] != ' ' || str[i+1] != ' ')) 
            str[n++] = str[i];
    }

    if(str[strlen(str)-1] == ' ')          //Fim da String
        str[n-1] = '\0';
    
    n = 0;
    if(str[0] == ' ') {     //Inicio da String
        for(int i = 1; i < strlen(str); i++) 
            str[n++] = str[i];
    }
    
    for(n = 0; n < strlen(str); n++) {    //a seguir aos ;
        if((str[n-1] == ';') && (str[n] == ' ')) {  
            for(int i = n; i < strlen(str); i++)
                str[i] = str[i+1];
        }
    }

    str[n-1] = '\0';

    return str;
}

int main (int argc, char **argv) {
    char str[200];

    FILE* file = fopen("file.txt", "r");
    fgets(str, 200, file);

    printf("[%s]\n", cutEndingSpaces(str));
    return 0;
}