#include "TP3.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define REDIMENSION 10
#define INITIALSIZE 2

DinRef_t *dinRefCreate(int initSpace) {

  DinRef_t *references = malloc(sizeof(DinRef_t));

  
  if (references == NULL) {
    printf("Erro na criação de DinRef_t! \n");
    return NULL;
  }

  references->refs = malloc(sizeof(MP3Tag_t*) * initSpace);  
  references->count = 0;
  references->space = initSpace;

  return references;
}

void dinRefDelete(DinRef_t *ref) { 
  free(ref->refs);
  free(ref);
}

void dinRefAdd(DinRef_t *ref, MP3Tag_t *tag) {
  
  if (ref->count == ref->space) {
    printf("No more space, reallocating memory\n");
    ref->refs = realloc(ref->refs, (ref->space + REDIMENSION) * sizeof(MP3Tag_t *));
    ref->space += REDIMENSION;
    printf("New array size: %d\n", ref->space);
  }

  ref->refs[ref->count] = tag;
  printf("Added artist: %s\n", ref->refs[ref->count]->artist);
  (ref->count)++;

}

Manage_t *manCreate (void){
  
  Manage_t *manage = malloc(sizeof(Manage_t));
  manage->refA = dinRefCreate(INITIALSIZE);
  manage->refT = dinRefCreate(INITIALSIZE);

  return manage;
}

void manDelete (Manage_t *man){
  
  dinRefDelete(man->refA);
  dinRefDelete(man->refT);
  free(man);

  printf("\n\nFreed all memory\n");
}

void manAddTag(Manage_t *man, MP3Tag_t *tag){

  printf("\n Struct A:\n");
  dinRefAdd(man->refA, tag);
  printf("\n Struct T: \n");
  dinRefAdd(man->refT, tag);
  
}

int main(void) {

  Manage_t *manage = manCreate();

  if(manage == NULL)
    return -1;

  MP3Tag_t teste, teste1, teste2;


  strcpy(teste.artist, "tiagovski");
  strcpy(teste1.artist, "Sir Kazzio");
  strcpy(teste2.artist, "Wuant");

  manAddTag(manage, &teste);
  manAddTag(manage, &teste1);
  manAddTag(manage, &teste2);


  manDelete(manage);
  
  
  return 0;
}