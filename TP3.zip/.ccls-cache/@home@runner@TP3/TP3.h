#include <stdio.h>
#include <stdlib.h>
#include "TP2.h"

typedef struct{
  int space;
  int count;
  MP3Tag_t **refs;
} DinRef_t;

typedef struct{
  DinRef_t *refA;
  DinRef_t *refT;
} Manage_t;