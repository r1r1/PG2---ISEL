#include "tags.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>



int main(void) {

  TagArr_t tArr;
  TagRef_t rArr;
  char scan;

  tagArrInit(&tArr);
  tableRead("tag-table.csv", &tArr);
  setupEnd(&tArr, &rArr);

  while (1) {

    printf("\n\nIntroduza o comando que pretende realizar:\n"
           "a - Listar por Artist - Album - Title\n"
           "t - Listar por Title - Artist - Album\n"
           "s - Procurar música\n"
           "q   - Sair\n\n");

    scanf("%c", &scan);
    getchar();

    command(&tArr, &rArr, &scan);
  }

  return 0;
}