#include "tags.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>



int main(int argc, char** argv) {

  TagArr_t tArr;
  TagRef_t rArr;
  char scan;

  tagArrInit(&tArr);

  // Falta ler da linha de comandos e passar o argv para o tableRead
  // argv [1] deve ser o nome do ficheiro csv.

  //int read = tableRead(argv[1], &tArr);
  
  int read = tableRead("tag-table.csv", &tArr);

  if(read == -1){
    printf("Error while reading table!\n");
    exit(-1);
  }
  
  setupEnd(&tArr, &rArr);

  while (1) {

    printf("\n\nIntroduza o comando que pretende realizar:\n"
           "a - Listar por Artist - Album - Title\n"
           "t - Listar por Title - Artist - Album\n"
           "s - Procurar música\n"
           "q   - Sair\n\n");

    scanf("%c", &scan);
    getchar();
    command(&tArr, &rArr, &scan);
  }

  return 0;
}