#include <ctype.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int fields(char *line, char *ptrs[], int max_fields);
char *cutEndingSpaces(char *str);