#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char *cutEndingSpaces(char *str){
  
  	int i = 0, j = 0, z = 0;

  char *dst = malloc(sizeof(char)*100);
  char *ptrInit = str;
  char* ptrEndField = str;
  char* nextField = str;


  while(*(nextField+1) != '\0'){
    
    for(; str[z] != ';'; z++)
      ptrEndField++;

    nextField = ptrEndField;

    while(*ptrEndField == ' ' || *ptrEndField == ';')
      ptrEndField--;

    for(; str[i] == ' '; i++){
      str++;     // Avança o pointer str pela string ate n ver espaços
    }
    str++;

    for(; (ptrEndField - str + 1) != 0; j++){
      dst[j] = *str;
      str++;
    }
    dst[j] = ';';   

  }
    dst[++j] = '\0';
  //printf("NextField aponta para (%s)\n", nextField);
  //printf("ptrEndField aponta para: (%c)\n",*ptrEndField);
  return dst;
}
 

int main(int argc, char **argv){
    
    char str[] = "   Teste disto   ; Teste dois  ;";
    char *finalTeste;
    //printf("Antes : (%s)\n",str);
    finalTeste = cutEndingSpaces(str);
    printf("Depois : (%s)\n", finalTeste);
    free(finalTeste);
    

    //printf("String antes %s\n", strTeste);
    //printf("\n\n String depois: %s\n", strSemEspaco);

    return 0;
}