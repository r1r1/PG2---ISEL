#include "functions.h"
#include <ctype.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SIZEOFSTR 200

int main(int argc, char **argv) {

  char str[SIZEOFSTR];
  char *ptrs[8] = {NULL};
  int identifiedFields = 0;

  FILE *file = fopen("amostra.txt", "r");

  while (fgets(str, sizeof(str), file) != NULL) {
    identifiedFields = fields(str, ptrs, 8);
    
    
    for (int i = 0; i < identifiedFields; i++) {
      if(i == (identifiedFields - 1)){
        printf("%s", ptrs[i]);
      }
      else
        printf("%s;",ptrs[i]);
    }
    printf("\n");
  }

  return 0;
}