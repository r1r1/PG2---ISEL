#include "TP3.h"

typedef struct lNode
{                     // Nó de lista ligada.
  struct lNode *next; // Ligação na lista.
  MP3Tag_t *ref;      // Ponteiro para a tag referenciada.
} LNode;

typedef struct tNode
{                             // Nó de árvore binária de pesquisa.
  struct tNode *left, *right; // Ligação na árvore.
  char *word;                 // Palavra associada ao nó – string alojada dinamicamente.
  LNode *list;                // Lista ligada com as referências da palavra.
} TNode;

typedef struct
{
  DinRef_t *refA;
  DinRef_t *refT;
  TNode *bst;
} Manage_t;

Manage_t *manCreate(void);
void manDelete(Manage_t *man);
void manAddTag(Manage_t *man, MP3Tag_t *tag);
void manCommand(Manage_t *man, char *cmdLine);
int tableReadStore(char *, Manage_t *);
void ErrorMsg(void *ptr, char *str);

void lAddRef(LNode **hp, MP3Tag_t *tag);

void lDelete(LNode *h);

void lPrintList(LNode *node);

void lScan(LNode *h, void (*action)(MP3Tag_t *));

void printTags(MP3Tag_t *teste);