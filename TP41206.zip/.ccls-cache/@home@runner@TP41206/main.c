#include "TP4.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Modulo de Arvore Bianria


void tAddWordRef(TNode **rp, char *w, MP3Tag_t *tag)
{

  if(*rp == NULL){
    
    *rp = malloc(sizeof(TNode));
    ErrorMsg(*rp, "Erro ao alocar memoria");

    (*rp)->word = malloc(strlen(w));
    ErrorMsg((*rp)->word, "Erro ao alocar memoria");

    lAddRef(&(*rp)->list,tag);
    ErrorMsg((*rp)->list, "Erro ao alocar memoria");
    
    (*rp)->list->ref = malloc(sizeof(MP3Tag_t));
    ErrorMsg((*rp)->list->ref, "Erro ao alocar memoria");
    
    (*rp)->left = (*rp)->right = NULL; 
    (*rp)->word = w;
    printf("%s\n", (*rp)->word);
    
    return;
  }

  int ret = strcmp((*rp)->word, w);
  
  if(ret < 0)
    tAddWordRef(&(*rp)->right, w, tag);
  
  if(ret > 0)
    tAddWordRef(&(*rp)->left, w, tag);

  return;
}

void tDelete(TNode *r)
{
  if(r == NULL)
    return;
  
  tDelete(r->left);
  tDelete(r->right);
  
  lDelete(r->list);
  //free(r->word); munmap_chunk(): invalid pointer, não entendo porquê
  free(r);
  
}

/*TNode *tSearch(TNode *r, char *w)
{
  int res;

  if (r == NULL)
    return NULL;
  else if (r != NULL)
  {
    res = strcmp(w, r->word);
    if (res < 0)
      search(r->left, w);
    else if (res > 0)
      search(r->right, w);
    else
      return (TNode *); // falta a referência
  }
}*/

int main(void)
{

  TNode *teste = malloc(sizeof(TNode));
  teste = NULL;
  char string[64] = "Tiagovski";
  MP3Tag_t tag1;

  strcpy(tag1.artist, string);

  tAddWordRef(&teste, string, &tag1);
  tAddWordRef(&teste, "Peido",&tag1);
  tAddWordRef(&teste, "Hamburguer na chapa",&tag1);

  tDelete(teste);

  // lPrintList(teste);


  return 0;
}