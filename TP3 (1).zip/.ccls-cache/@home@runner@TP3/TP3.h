#include <stdio.h>
#include <stdlib.h>
#include "TP2.h"

#define REDIMENSION 10
#define INITIALSIZE 2

typedef struct{
  int space;
  int count;
  MP3Tag_t **refs;
} DinRef_t;

typedef struct{
  DinRef_t *refA;
  DinRef_t *refT;
} Manage_t;

DinRef_t *dinRefCreate(int );
void dinRefDelete(DinRef_t *);
void dinRefAdd(DinRef_t *, MP3Tag_t *);
Manage_t *manCreate (void);
void manDelete (Manage_t *);
void manAddTag(Manage_t *, MP3Tag_t *);