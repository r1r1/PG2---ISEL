#include "TP3.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>



int main(void) {

  Manage_t *manage = manCreate();

  if(manage == NULL)
    return -1;

  MP3Tag_t teste, teste1, teste2;


  strcpy(teste.artist, "tiagovski");
  strcpy(teste1.artist, "Sir Kazzio");
  strcpy(teste2.artist, "Wuant");

  manAddTag(manage, &teste);
  manAddTag(manage, &teste1);
  manAddTag(manage, &teste2);


  manDelete(manage);
  
  
  return 0;
}