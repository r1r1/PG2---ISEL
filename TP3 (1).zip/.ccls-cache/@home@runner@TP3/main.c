#include "TP3.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int sCompFunc(const void *ptr1, const void *ptr2) {
  MP3Tag_t *tag1 = (MP3Tag_t *)ptr1;
  MP3Tag_t *tag2 = (MP3Tag_t *)ptr2;

  int res = strcmp(tag1->title, tag2->title);
  return res;
}

MP3Tag_t *dinRefSearch(DinRef_t *ref, void *key,
                       int (*compar)(const void *, const void *)) {

  MP3Tag_t *toFind = (MP3Tag_t *)key;

  MP3Tag_t *found = (MP3Tag_t *)bsearch(toFind, ref->refs, ref->count,
                                        sizeof(MP3Tag_t *), sCompFunc);

  printf("%s\n", found->title);

  return found;
}



int tableReadStore(char *tableName, Manage_t *man){
  
  char buf[255];
  char *fieldsFound[8];
  int res = 0;
  MP3Tag_t tag;

  FILE *File = fopen(tableName, "r");

  fgets(buf, sizeof(buf), File); // Ignora a primeira linha

  while (fgets(buf, sizeof(buf), File) != NULL) {
    res = fields(buf, fieldsFound, sizeof(fieldsFound));

    if (res != 0) {
      
      loadTag(fieldsFound, &tag);
      manAddTag(man, &tag);
            
    }
  }

  printf("\n\n");

  
  fclose(File);
  return 0;
  
}

int main(void) {

  Manage_t *manage = manCreate();
  char command;

  if (manage == NULL)
    return -1;

  int ret = tableReadStore("tag-table.csv", manage);

  printf("After store (not working) \n");
  dinRefScan(manage->refA, printTag);

  printf("\nAfter store T (not working)\n");
  dinRefScan(manage->refT, printTag);
  
  manSort(manage);


  
  /*
  while(1){
    printf("\nIntroduza o comando que pretende: ");
    
    command = getchar();
    getchar();
    
    if(command == 'q')
      break;
    
    printf("%c\n", command);
    manCommand(manage, &command);

  }*/


  manDelete(manage);

  return 0;
}