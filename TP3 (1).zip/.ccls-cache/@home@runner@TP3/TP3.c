#include <stdio.h>
#include <stdlib.h>
#include "TP3.h"


DinRef_t *dinRefCreate(int initSpace) {

  DinRef_t *references = malloc(sizeof(DinRef_t));

  if (references == NULL) {
    printf("Erro na criação de DinRef_t! \n");
    return NULL;
  }

  references->refs = malloc(sizeof(MP3Tag_t*) * initSpace);  
  references->count = 0;
  references->space = initSpace;

  return references;
}

void dinRefDelete(DinRef_t *ref) { 
  free(ref->refs);
  free(ref);
}

void dinRefAdd(DinRef_t *ref, MP3Tag_t *tag) {

  int count = ref->count;
  
  if (ref->count == ref->space) {
    //printf("No more space, reallocating memory\n");
    ref->refs = realloc(ref->refs, (ref->space + REDIMENSION) * sizeof(MP3Tag_t *));
    ref->space += REDIMENSION;
    //printf("New array size: %d\n", ref->space);
  }

  ref->refs[count] = tag;
  printf("\nAdded tag to ref->refs[%d]:\n", ref->count);
  printTag(ref->refs[ref->count]);
  
  (ref->count)++;
  
}

void manAddTag(Manage_t *man, MP3Tag_t *tag){
  dinRefAdd(man->refA, tag);
  dinRefAdd(man->refT, tag); 
}

void dinRefSort (DinRef_t *ref, int(*compar)(const void*, const void*)){
  qsort(ref->refs, ref->count, sizeof(ref->refs[0]), compar);
}

void dinRefScan (DinRef_t *ref, void (*action) (MP3Tag_t *)){
  
  for(int i = 0; i < ref->count; i++){
    action(ref->refs[i]);
  }
  
}

Manage_t *manCreate (void){
  
  Manage_t *manage = malloc(sizeof(Manage_t));
  manage->refA = dinRefCreate(INITIALSIZE);
  manage->refT = dinRefCreate(INITIALSIZE);

  return manage;
}

void manDelete (Manage_t *man){
  
  dinRefDelete(man->refA);
  dinRefDelete(man->refT);
  free(man);

  printf("\n\nFreed all memory\n");
}



void manSort(Manage_t *man){
  dinRefSort(man->refA, aCompFunc);
  dinRefSort(man->refT, tCompFunc);
}

void printTag(MP3Tag_t *tag) {
  printf("%s;%s;%s;%d;%s", (tag->artist), (tag->album),
             (tag->title), tag->year, tag->comment);
  printf(";%c;%c\n", tag->track, tag->genre);
}

void manCommand(Manage_t *man, char *cmdLine) {

  if (*cmdLine == 'a')
    dinRefScan(man->refA, printTag);
    
  if(*cmdLine == 't')
    dinRefScan(man->refT, printTag);

  // Falta fazer a parte do search
}

